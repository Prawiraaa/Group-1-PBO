I Putu Arya Prawira Wiwekananda
Mardhatillah Shevy Ananti
Raden Roro Kayla Angelica Priambudi
Talitha Hayyinas Sahala