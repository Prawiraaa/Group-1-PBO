import java.util.Scanner;

public class PetShop {
    public static void main(String [] args) {
        System.out.println("Enter customer name:");
        Scanner scan = new Scanner(System.in);
        String custName = scan.nextLine();
        System.out.println("Enter the number of the product catalogue you wish to buy:\n1. Cat (with or without additionals)\n2. Dog (with or without additionals)\n3. Hamster (with or without additionals)\n4. Cat Food only\n5. Dog Food only\n6. Hamster Food only\n7. Cat Cage only\n8. Dog Cage only\n9. Hamster Cage only");
        int product1 = scan.nextInt();
        if (product1 == 1){
            System.out.println("Enter the number of the product catalogue if you wish to buy any additional product:\n1. Cat Food \n2. Cat Cage \n3. Cat Food & Cat Cage \n4.No additional product");
            int product2 = scan.nextInt();
            if (product2 == 1){
                Transaction trans = new Transaction(custName, "Cat + Cat Food", "2100000");
                trans.displayTransaction();
            }
            if (product2 == 2){
                Transaction trans = new Transaction(custName, "Cat + Cat Cage", "2100000");
                trans.displayTransaction();
            }
            if (product2 == 3){
                Transaction trans = new Transaction(custName, "Cat + Cat Food + Cat Cage", "2200000");
                trans.displayTransaction();
            }
            if (product2 == 4){
                Transaction trans = new Transaction(custName, "Cat", "2000000");
                trans.displayTransaction();
            }
            
        }
        if (product1 == 2){
            System.out.println("Enter the number of the product catalogue if you wish to buy any additional product:\n1. Dog Food \n2. Dog Cage \n3. Dog Food & Dog Cage \n4.No additional product");
            int product2 = scan.nextInt();
            if (product2 == 1){
                Transaction trans = new Transaction(custName, "Dog + Dog Food", "3150000");
                trans.displayTransaction();
            }
            if (product2 == 2){
                Transaction trans = new Transaction(custName, "Dog + Dog Cage", "3150000");
                trans.displayTransaction();
            }
            if (product2 == 3){
                Transaction trans = new Transaction(custName, "Dog + Dog Food + Dog Cage", "3300000");
                trans.displayTransaction();
            }
            if (product2 == 4){
                Transaction trans = new Transaction(custName, "Dog", "3000000");
                trans.displayTransaction();
            }
        }

        if (product1 == 3){
            System.out.println("Enter the number of the product catalogue if you wish to buy any additional product:\n1. Hamster Food \n2. Hamster Cage \n3. Hamster Food & Hamster Cage \n4.No additional product");
            int product2 = scan.nextInt();
            if (product2 == 1){
                Transaction trans = new Transaction(custName, "Hamster + Hamster Food", "575000");
                trans.displayTransaction();
            }
            if (product2 == 2){
                Transaction trans = new Transaction(custName, "Hamster + Hamster Cage", "575000");
                trans.displayTransaction();
            }
            if (product2 == 3){
                Transaction trans = new Transaction(custName, "Hamster + Hamster Food + Hamster Cage", "650000");
                trans.displayTransaction();
            }
            if (product2 == 4){
                Transaction trans = new Transaction(custName, "Hamster", "500000");
                trans.displayTransaction();
            }
        }

        if (product1 == 4){
            Transaction trans = new Transaction(custName, "Cat Food", "100000");
            trans.displayTransaction();
        }

        if (product1 == 5){
            Transaction trans = new Transaction(custName, "Dog Food", "150000");
            trans.displayTransaction();
        }

        if (product1 == 6){
            Transaction trans = new Transaction(custName, "Hamster Food", "75000");
            trans.displayTransaction();
        }

        if (product1 == 7){
            Transaction trans = new Transaction(custName, "Cat Cage", "100000");
            trans.displayTransaction();
        }

        if (product1 == 8){
            Transaction trans = new Transaction(custName, "Dog Cage", "150000");
            trans.displayTransaction();
        }

        if (product1 == 9){
            Transaction trans = new Transaction(custName, "Hamster Cage", "75000");
            trans.displayTransaction();
        }

        if (product1 > 9){
            System.out.println("Product not found.");
        }
    }
}
