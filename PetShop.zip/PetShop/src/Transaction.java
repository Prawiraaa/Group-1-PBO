public class Transaction {
  
    public String customerName;
    public String items;
    public String totalPrice;

    public Transaction (String name, String products, String tPrice){
        this.customerName = name;
        this.items = products;
        this.totalPrice = tPrice;
    }
    
        public void displayTransaction(){
            System.out.println("Customer Name: " + customerName + "\nItems: " + items + "\nTotal Price: " + totalPrice);
        }
    }